# Youtube Counter
Small web extention which limits the number of youtube videos you watch.
You set a limit and a rediret url then once you have watched that many videos then you get redirected to the redirect url.

